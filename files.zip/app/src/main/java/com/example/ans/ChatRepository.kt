package com.example.ans

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

enum class MessageSender { User, Assistant }
data class ChatMessage(val sender: MessageSender, val text: String)

class ChatRepository(private val context: Context) {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }

    // store API key securely using EncryptedSharedPreferences
    private val prefs by lazy {
        val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        EncryptedSharedPreferences.create(
            "ans_prefs",
            masterKeyAlias,
            context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private var apiKey: String?
        get() = prefs.getString("OPENAI_API_KEY", null)
        set(value) = prefs.edit().putString("OPENAI_API_KEY", value).apply()

    suspend fun sendUserMessage(text: String) {
        // ensure key exists; if not, ask user (simplified: prompt via blocking dialog not included here)
        if (apiKey.isNullOrBlank()) {
            // In real app: show dialog to let user paste their key and call setApiKey()
            // For this sample we throw an exception so developer can test
            throw IllegalStateException("OpenAI API key not set. Set it programmatically via repository.setApiKey(...) or implement UI to set it.")
        }
        appendLocalMessage(MessageSender.User, text)
        val assistant = callOpenAI(apiKey!!, text)
        appendLocalMessage(MessageSender.Assistant, assistant)
    }

    fun setApiKey(key: String) {
        apiKey = key.trim()
    }

    private fun appendLocalMessage(sender: MessageSender, text: String) {
        _messages.value = _messages.value + ChatMessage(sender, text)
    }

    private fun callOpenAI(key: String, userPrompt: String): String {
        val url = "https://api.openai.com/v1/chat/completions"
        val payload = OpenAIRequest(
            model = "gpt-3.5-turbo",
            messages = listOf(Message(role = "user", content = userPrompt))
        )
        val bodyJson = json.encodeToString(OpenAIRequest.serializer(), payload)
        val body = bodyJson.toRequestBody("application/json; charset=utf-8".toMediaType())
        val req = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $key")
            .post(body)
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                val text = resp.body?.string() ?: "خطأ غير معروف"
                return "خطأ من الخادم: $text"
            }
            val respText = resp.body?.string() ?: return "استجابة فارغة"
            val parsed = json.decodeFromString(OpenAIResponse.serializer(), respText)
            return parsed.choices.firstOrNull()?.message?.content?.trim() ?: "لا توجد إجابة"
        }
    }
}

@Serializable
data class Message(val role: String, val content: String)

@Serializable
data class OpenAIRequest(val model: String, val messages: List<Message>)

@Serializable
data class Choice(val index: Int, val message: Message)

@Serializable
data class OpenAIResponse(val id: String, val objectType: String? = null, val created: Long? = null,
                          val choices: List<Choice> = emptyList(), val usage: Map<String, Int>? = null) {
    @SerialName("object") var _object: String? = objectType
}