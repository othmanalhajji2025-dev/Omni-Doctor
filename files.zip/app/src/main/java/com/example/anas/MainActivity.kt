package com.example.anas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

class MainActivity : ComponentActivity() {
    private lateinit var repo: ChatRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = ChatRepository(this)
        setContent {
            MaterialTheme {
                ChatScreen(repo)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(repo: ChatRepository) {
    var input by remember { mutableStateOf("") }
    val messages by repo.messages.collectAsState()
    val hasKey by repo.hasKey.collectAsState()
    var keyInput by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    Scaffold(topBar = { TopAppBar(title = { Text("أنس — ChatGPT") }) }) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (!hasKey) {
                // show key input UI
                Row(modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)) {
                    OutlinedTextField(
                        value = keyInput,
                        onValueChange = { keyInput = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        placeholder = { Text("أدخل مفتاح OpenAI (sk-...)") }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = {
                        if (keyInput.isNotBlank()) {
                            repo.setApiKey(keyInput.trim())
                            keyInput = ""
                        }
                    }) {
                        Text("حفظ")
                    }
                }
                Text(
                    text = "المفتاح يُحفظ مشفّراً في جهازك. لا ترفع المفتاح إلى مستودعات عامة.",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }

            LazyColumn(modifier = Modifier.weight(1f).padding(8.dp)) {
                items(messages.size) { i ->
                    val m = messages[i]
                    MessageBubble(m.sender, m.text)
                }
            }
            Row(modifier = Modifier.padding(8.dp)) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    placeholder = { Text("اكتب رسالتك...") },
                    keyboardActions = KeyboardActions(onDone = {
                        // handled by send button
                    })
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = {
                    if (input.isBlank()) return@Button
                    val text = input.trim()
                    input = ""
                    coroutineScope.launch { repo.sendUserMessage(text) }
                }) {
                    Text("إرسال")
                }
            }
        }
    }
}

@Composable
fun MessageBubble(sender: MessageSender, text: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Surface(
            tonalElevation = 2.dp,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.padding(4.dp)
        ) {
            Text(
                text = (if (sender == MessageSender.User) "أنت: " else "أنس: ") + text,
                modifier = Modifier.padding(12.dp)
            )
        }
    }
}