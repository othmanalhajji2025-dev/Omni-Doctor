const express = require('express');
const fetch = require('node-fetch');
const app = express();
app.use(express.json());
const OPENAI_KEY = process.env.OPENAI_KEY; // ضع مفتاحك في متغير بيئة
app.post('/chat', async (req, res) => {
  const body = {
    model: "gpt-3.5-turbo",
    messages: [{ role: "user", content: req.body.message }]
  };
  const r = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${OPENAI_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });
  const data = await r.json();
  res.json(data);
});
app.listen(3000, () => console.log('proxy listening on 3000'));